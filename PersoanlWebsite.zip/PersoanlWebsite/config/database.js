module.exports = {
    'url': 'mongodb://suraj:suraj@ds139909.mlab.com:39909/crudapp1'
};